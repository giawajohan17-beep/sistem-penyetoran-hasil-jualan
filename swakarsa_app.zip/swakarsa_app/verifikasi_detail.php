<?php
session_start();
include 'koneksi.php';

// Ambil ID dan Tanggal dari URL
$id_karyawan = $_GET['id'] ?? '';
$tgl = $_GET['tgl'] ?? '';

// 1. Ambil data setoran
$query = mysqli_query($koneksi, "SELECT sh.*, k.nama_karyawan 
                                 FROM stok_harian sh 
                                 JOIN karyawan k ON sh.id_karyawan = k.id_karyawan 
                                 WHERE sh.id_karyawan = '$id_karyawan' 
                                 AND DATE(sh.tanggal) = '$tgl' 
                                 LIMIT 1");
$data = mysqli_fetch_assoc($query);

// 2. Ambil detail menu yang laku
$detail_menu = mysqli_query($koneksi, "SELECT sh.*, m.nama_kopi 
                                       FROM stok_harian sh 
                                       JOIN menu m ON sh.id_menu = m.id_menu 
                                       WHERE sh.id_karyawan = '$id_karyawan' 
                                       AND DATE(sh.tanggal) = '$tgl'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Verifikasi - <?php echo $data['nama_karyawan'] ?? 'Karyawan'; ?></title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #1a0633; color: white; padding: 20px; }
        .card-detail { 
            max-width: 500px; 
            margin: 0 auto; 
            background: #2d1350; 
            padding: 25px; 
            border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
        }
        .header { text-align: center; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px; }
        th { text-align: left; color: #aaa; border-bottom: 1px solid #444; padding: 10px; }
        td { padding: 10px; border-bottom: 1px solid #3d2461; }
        
        .omzet-box { 
            background: rgba(255,255,255,0.05); 
            padding: 15px; 
            border-radius: 12px; 
            margin-top: 20px; 
            border-left: 4px solid #27ae60;
        }
        
        /* Bukti Transfer */
        .foto-container { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 15px; }
        .foto-bukti { 
            width: 100px; height: 100px; object-fit: cover; 
            border-radius: 10px; cursor: pointer; border: 2px solid #e67e22;
            transition: 0.3s;
        }
        .foto-bukti:hover { transform: scale(1.05); }

        /* Modal Gambar */
        .modal {
            display: none; position: fixed; z-index: 1000; 
            padding-top: 50px; left: 0; top: 0; width: 100%; height: 100%; 
            background-color: rgba(0,0,0,0.9); overflow: auto;
        }
        .modal-content {
            margin: auto; display: block; width: 90%; max-width: 500px;
            border-radius: 10px; animation: zoom 0.3s;
        }
        @keyframes zoom { from {transform: scale(0)} to {transform: scale(1)} }
        .close {
            position: absolute; top: 20px; right: 35px; color: #f1f1f1;
            font-size: 40px; font-weight: bold; cursor: pointer;
        }

        .btn-back { 
            display: block; text-align: center; margin-top: 25px; 
            color: #3498db; text-decoration: none; font-weight: bold; 
        }
    </style>
</head>
<body>

<div class="card-detail">
    <div class="header">
        <h2>📊 <?php echo $data['nama_karyawan'] ?? ''; ?></h2>
        <small>📅 <?php echo !empty($tgl) ? date('d F Y', strtotime($tgl)) : ''; ?></small>
    </div>

    <table>
        <thead>
            <tr>
                <th>MENU</th>
                <th style="text-align:center;">AWAL</th>
                <th style="text-align:center;">LAKU</th>
                <th style="text-align:center;">SISA</th> </tr>
        </thead>
        <tbody>
            <?php while($m = mysqli_fetch_assoc($detail_menu)) { ?>
            <tr>
                <td><?php echo $m['nama_kopi']; ?></td>
                <td align="center"><?php echo $m['jumlah_awal']; ?></td>
                <td align="center" style="color:#27ae60; font-weight:bold;"><?php echo $m['terjual']; ?></td>
                <td align="center" style="color:#e74c3c; font-weight:bold;"><?php echo $m['sisa_stok']; ?></td> </tr>
            <?php } ?>
        </tbody>
    </table>

    <div class="omzet-box">
        <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
            <span>💵 Tunai:</span>
            <strong>Rp <?php echo number_format($data['nominal_tunai'] ?? 0, 0, ',', '.'); ?></strong>
        </div>
        <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
            <span>💳 Transfer:</span>
            <strong>Rp <?php echo number_format($data['nominal_transfer'] ?? 0, 0, ',', '.'); ?></strong>
        </div>
        <hr style="border:0; border-top:1px solid #444;">
        <div style="display:flex; justify-content:space-between; font-size:18px; color:#ff9f43;">
            <strong>TOTAL:</strong>
            <strong>Rp <?php echo number_format(($data['nominal_tunai'] ?? 0) + ($data['nominal_transfer'] ?? 0), 0, ',', '.'); ?></strong>
        </div>
    </div>

    <h4 style="margin-top:25px; margin-bottom:10px;">🖼️ Bukti Transfer:</h4>
    <div class="foto-container">
        <?php 
        if (!empty($data['bukti_transfer'])) {
            $fotos = explode('*', $data['bukti_transfer']);
            foreach ($fotos as $img) {
                if (!empty($img)) {
                    echo '<img src="'.$img.'" class="foto-bukti" onclick="tampilModal(this.src)" alt="Bukti Transfer">';
                }
            }
        } else {
            echo '<p style="color:#777; font-size:12px;">(Tidak ada bukti foto)</p>';
        }
        ?>
    </div>

    <a href="dashboard_admin.php" class="btn-back">⬅ Kembali ke Dashboard</a>
</div>

<div id="myModal" class="modal" onclick="tutupModal()">
    <span class="close">&times;</span>
    <img class="modal-content" id="img01">
</div>

<script>
function tampilModal(src) {
    var modal = document.getElementById("myModal");
    var modalImg = document.getElementById("img01");
    modal.style.display = "block";
    modalImg.src = src;
}

function tutupModal() {
    document.getElementById("myModal").style.display = "none";
}
</script>

</body>
</html>