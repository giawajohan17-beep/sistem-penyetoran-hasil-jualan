<?php
session_start();
include 'koneksi.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit();
}

// 1. Ambil Data List Karyawan & Menu (Ditaruh di atas agar tidak Undefined)
$karyawan_list = mysqli_query($koneksi, "SELECT * FROM karyawan ORDER BY no_sepeda ASC");
$menu_list = mysqli_query($koneksi, "SELECT * FROM menu ORDER BY kategori ASC");

// 2. Proses Simpan Stok
if (isset($_POST['simpan_stok'])) {
    $id_karyawan = $_POST['id_karyawan'];
    $tanggal = date('Y-m-d');
    $tipe_update = isset($_POST['tipe_update']) ? $_POST['tipe_update'] : 'set_awal';

    foreach ($_POST['jumlah_menu'] as $id_menu => $jumlah) {
        $jumlah = (int)$jumlah;
        if ($jumlah <= 0) continue; 

        if ($tipe_update == 'set_awal') {
            mysqli_query($koneksi, "DELETE FROM stok_harian WHERE id_karyawan='$id_karyawan' AND id_menu='$id_menu' AND DATE(tanggal)='$tanggal'");
            mysqli_query($koneksi, "INSERT INTO stok_harian (id_karyawan, id_menu, tanggal, jumlah_awal, terjual, sisa_stok) 
                                   VALUES ('$id_karyawan', '$id_menu', '$tanggal', '$jumlah', 0, 0)");
        } else {
            mysqli_query($koneksi, "UPDATE stok_harian SET jumlah_awal = jumlah_awal + $jumlah 
                                   WHERE id_karyawan='$id_karyawan' AND id_menu='$id_menu' AND DATE(tanggal)='$tanggal'");
        }
    }
    echo "<script>alert('Stok Berhasil Disimpan!'); window.location='stok_awal.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Input Stok - PT Swakarsa</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f4f7f6; padding: 15px; margin: 0; }
        .card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); max-width: 500px; margin: auto; }
        h2 { text-align: center; color: #2c3e50; margin-bottom: 20px; }
        .menu-item { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; padding: 12px 0; }
        .btn-simpan { background: #27ae60; color: white; border: none; padding: 15px; border-radius: 8px; cursor: pointer; width: 100%; font-weight: bold; font-size: 16px; margin-top: 20px; }
        /* Style untuk Tombol Kembali */
        .btn-kembali { display: block; background: #95a5a6; color: white; text-align: center; padding: 12px; border-radius: 8px; text-decoration: none; font-weight: bold; margin-top: 10px; font-size: 14px; }
        .btn-kembali:hover { background: #7f8c8d; }
        select, input[type="number"] { padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
    </style>
</head>
<body>

<div class="card">
    <h2>📦 Input Stok Sepeda</h2>
    <form action="" method="POST">
        <label><strong>Pilih Karyawan:</strong></label><br>
        <select name="id_karyawan" required style="width: 100%; margin: 10px 0;">
            <option value="">-- Pilih Karyawan --</option>
            <?php while($k = mysqli_fetch_assoc($karyawan_list)) { ?>
                <option value="<?= $k['id_karyawan']; ?>"><?= $k['no_sepeda']; ?> - <?= $k['nama_karyawan']; ?></option>
            <?php } ?>
        </select>

        <input type="hidden" name="tipe_update" value="set_awal">

        <h4 style="margin-top:20px; border-left: 4px solid #e67e22; padding-left: 10px;">Daftar Menu:</h4>
        <?php 
        if ($menu_list && mysqli_num_rows($menu_list) > 0) {
            mysqli_data_seek($menu_list, 0); 
            while($m = mysqli_fetch_assoc($menu_list)) { ?>
                <div class="menu-item">
                    <span><?= $m['nama_kopi']; ?></span>
                    <input type="number" name="jumlah_menu[<?= $m['id_menu']; ?>]" value="0" min="0" style="width: 70px;">
                </div>
            <?php } 
        } else {
            echo "<p style='color:red;'>Menu kosong! Cek database.</p>";
        } ?>

        <button type="submit" name="simpan_stok" class="btn-simpan">SIMPAN DATA STOK ✅</button>
        
        <a href="dashboard_admin.php" class="btn-kembali">⬅️ KEMBALI KE DASHBOARD</a>
    </form>
</div>

</body>
</html>