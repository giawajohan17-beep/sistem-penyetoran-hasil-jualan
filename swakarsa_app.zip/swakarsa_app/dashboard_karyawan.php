<?php 
session_start();
include 'koneksi.php';

if (!isset($_SESSION['status']) || $_SESSION['status'] != "login") {
    header("location:index.php?pesan=belum_login");
    exit();
}

$id_karyawan = $_SESSION['id_karyawan'];
$tanggal = date('Y-m-d'); 

$query_stok = mysqli_query($koneksi, "SELECT sh.*, m.nama_kopi, m.harga_per_cup 
                                      FROM stok_harian sh 
                                      JOIN menu m ON sh.id_menu = m.id_menu 
                                      WHERE sh.id_karyawan = '$id_karyawan' 
                                      AND DATE(sh.tanggal) = '$tanggal'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setoran - PT Swakarsa</title>
    <script src="https://cdn.jsdelivr.net/npm/heic2any@0.0.3/dist/heic2any.min.js"></script>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f0f2f5; padding: 15px; margin: 0; }
        
        /* CONTAINER UTAMA: Dibuat ramping dan di tengah */
        .main-wrapper { 
            max-width: 600px; /* Mengecilkan lebar konten */
            margin: 0 auto;   /* Memposisikan di tengah layar */
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        h3 { text-align: center; color: #333; margin-bottom: 20px; border-bottom: 2px solid #e67e22; padding-bottom: 10px; }

        .card { 
            background: #fff; 
            padding: 12px 15px; 
            border-radius: 10px; 
            margin-bottom: 10px; 
            border: 1px solid #eee; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
        }

        .input-terjual { 
            width: 60px; 
            padding: 8px; 
            text-align: center; 
            border: 2px solid #e67e22; 
            border-radius: 8px; 
            font-weight: bold; 
            font-size: 16px; 
        }

        .input-error { border-color: #e74c3c !important; background-color: #ffdada !important; }
        
        .total-box { 
            background: #2c3e50; 
            color: white; 
            padding: 15px; 
            border-radius: 12px; 
            text-align: center; 
            margin: 15px 0; 
            border-bottom: 4px solid #e67e22; 
        }
        .total-box h2 { margin: 5px 0 0 0; color: #ff9f43; font-size: 28px; }

        .form-control { width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ddd; border-radius: 8px; box-sizing: border-box; font-size: 15px; }
        
        .btn-kirim { width: 100%; padding: 15px; background: #27ae60; color: white; border: none; border-radius: 10px; font-weight: bold; font-size: 16px; cursor: pointer; margin-top: 10px; }
        .btn-logout { width: 100%; padding: 12px; background: #e74c3c; color: white; border: none; border-radius: 10px; font-weight: bold; font-size: 14px; cursor: pointer; margin-top: 15px; display: block; text-align: center; text-decoration: none; }
        
        .status-foto { font-size: 12px; font-weight: bold; color: blue; display: block; margin-top: 5px; }
        #container-preview img { width: 70px; height: 70px; object-fit: cover; border-radius: 8px; border: 2px solid #e67e22; }
    </style>
</head>
<body>

<div class="main-wrapper">
    <h3>Setoran: <?php echo $_SESSION['nama_karyawan']; ?></h3>

    <form action="proses_setoran.php" method="POST" onsubmit="return cekFinal()">
        
        <?php while($row = mysqli_fetch_assoc($query_stok)) { ?>
        <div class="card">
            <div>
                <strong style="font-size: 14px;"><?php echo $row['nama_kopi']; ?></strong><br>
                <small style="color: #666;">Stok: <?php echo $row['jumlah_awal']; ?> Cup</small>
            </div>
            <input type="number" name="terjual[<?php echo $row['id_stok']; ?>]" class="input-terjual hitung-cup" 
                   value="0" min="0" data-stok="<?php echo $row['jumlah_awal']; ?>" 
                   data-harga="<?php echo $row['harga_per_cup']; ?>" oninput="hitungOtomatis()">
        </div>
        <?php } ?>

        <div class="total-box">
            <span style="font-size: 12px;">ESTIMASI TOTAL OMZET:</span>
            <h2 id="display_total">Rp 0</h2>
        </div>

        <div style="padding: 10px; border: 1px solid #eee; border-radius: 10px;">
            <label>💰 <b>Uang Tunai:</b></label>
            <input type="number" name="nominal_tunai" class="form-control" placeholder="0">
            
            <label>💳 <b>Transfer / QRIS:</b></label>
            <input type="number" id="inputTransfer" name="nominal_transfer" class="form-control" placeholder="0">
            
            <label>📸 <b>Bukti Transfer:</b></label>
            <input type="file" id="fileInputMulti" class="form-control" accept="image/*" multiple>
            <input type="hidden" name="banyak_bukti_base64" id="banyak_base64">
            
            <span id="pesanProses" class="status-foto"></span>
            <div id="container-preview" style="display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px;"></div>
        </div>

        <button type="submit" id="tombolKirim" name="simpan" class="btn-kirim">KIRIM LAPORAN</button>
    </form>

    <!-- TOMBOL LOGOUT MANUAL -->
    <a href="logout.php" class="btn-logout" onclick="return confirm('Mau keluar aplikasi, Bang?')">LOGOUT / KELUAR</a>
</div>

<script>
function hitungOtomatis() {
    let totalSemua = 0;
    let adaError = false;
    const semuaInput = document.querySelectorAll('.hitung-cup');
    const btn = document.getElementById('tombolKirim');
    
    semuaInput.forEach(input => {
        const jumlah = parseInt(input.value) || 0;
        const stokMaks = parseInt(input.getAttribute('data-stok')) || 0;
        let harga = parseInt(input.getAttribute('data-harga')) || 0;
        
        if (jumlah > stokMaks) {
            input.classList.add('input-error');
            adaError = true;
        } else {
            input.classList.remove('input-error');
        }
        totalSemua += (jumlah * harga);
    });

    document.getElementById('display_total').innerText = "Rp " + totalSemua.toLocaleString('id-ID');
    btn.disabled = adaError;
    btn.style.background = adaError ? "#95a5a6" : "#27ae60";
    btn.innerText = adaError ? "STOK TIDAK CUKUP!" : "KIRIM LAPORAN";
}

let kumpulanBase64 = [];
document.getElementById('fileInputMulti').addEventListener('change', async function(e) {
    const files = e.target.files;
    if (files.length === 0) return;

    const btn = document.getElementById('tombolKirim');
    const pesan = document.getElementById('pesanProses');
    const wadahPreview = document.getElementById('container-preview');
    const hiddenInput = document.getElementById('banyak_base64');
    
    btn.disabled = true;
    pesan.innerText = "⏳ Memproses foto...";
    wadahPreview.innerHTML = ""; 
    kumpulanBase64 = [];

    for (let i = 0; i < files.length; i++) {
        let file = files[i];
        if (file.name.toLowerCase().endsWith(".heic")) {
            try {
                const blob = await heic2any({ blob: file, toType: "image/jpeg", quality: 0.6 });
                file = new File([blob], "foto_" + i + ".jpg", { type: "image/jpeg" });
            } catch (err) { console.error("HEIC Error"); }
        }

        const reader = new FileReader();
        reader.onload = function(event) {
            const img = new Image();
            img.onload = function() {
                const canvas = document.createElement('canvas');
                const MAX_WIDTH = 600;
                const scaleSize = MAX_WIDTH / img.width;
                canvas.width = MAX_WIDTH;
                canvas.height = img.height * scaleSize;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                
                const base64 = canvas.toDataURL('image/jpeg', 0.7);
                kumpulanBase64.push(base64);
                hiddenInput.value = kumpulanBase64.join('*');

                const thumb = document.createElement('img');
                thumb.src = base64;
                wadahPreview.appendChild(thumb);

                if (kumpulanBase64.length === files.length) {
                    btn.disabled = false;
                    pesan.innerText = "✅ " + files.length + " Foto siap!";
                    pesan.style.color = "green";
                }
            };
            img.src = event.target.result;
        };
        reader.readAsDataURL(file);
    }
});

function cekFinal() {
    const transfer = parseInt(document.getElementById('inputTransfer').value) || 0;
    const foto = document.getElementById('banyak_base64').value;
    if (transfer > 0 && !foto) {
        alert("Wajib upload bukti transfer!");
        return false;
    }
    return confirm("Kirim sekarang?");
}
window.onload = hitungOtomatis;
</script>

</body>
</html>